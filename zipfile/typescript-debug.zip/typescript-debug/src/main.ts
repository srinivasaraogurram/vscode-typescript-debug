import { Greeter } from '../src/greeter'
import * as input1 from "../src/data.json";

let greeter = new Greeter("Welcome, to ts debug");
greeter.greet('Sri')
let data = input1.arguments.input
greeter.processTCAMakeUpService(data);