"use strict";

export interface ISqsLambdaEventRecord {
  body: string;
}
